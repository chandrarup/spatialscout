# Rerunning this investigation

## Check the package (no raw data needed)

Run `verify.ipynb` top to bottom, or `python3 verify_package.py`, in this folder. It checks the file checksums, the
audit log's hash chain against the manifest's head hash, every cited number against `artifacts/`, and each audit
result's arithmetic from its own counts.

## Replay the model responses

`replay.json` lists every model call with its cache key. With the SpatialScout repository at the commit that made this
package, `make install && make serve`, then ask the question in `manifest.json` in the run mode it records; a cached
tool rerun re-runs every tool and serves the stored responses for the same keys.

## Rerun from raw data

1. `make install`
2. `make data`: downloads GSE286184 from GEO (GSE286184) and validates and labels every section.
3. `make audit`: recomputes the audit results, controls and composite figures into `artifacts/GSE286184/audit/`.
4. `make benchmark`: recomputes the verifier's numerical checks from the molecule tables.

Synthetic data (SYN-01) is rebuilt by `make fixtures`; its answers are known by construction.
